const Discord = require('discord.js');
require('dotenv').config()
let TOKEN = ('OTY4NDk5OTY2ODMyMTY4OTkw.Ymfv4Q.lja6-fGfHWvYI7yxaYzz_dIVw7I');

//Client creation
const client = new Discord.Client({
    intents: [
        "GUILDS",
        "GUILD_MESSAGES"
    ]
})

//Console
client.once('ready', () => {
    console.log('BOT IS READY');
});

client.on("messageCreate", (message) => {
    if (message.content == "Андрій"){
        message.reply("Терець")
    }
})













client.login(TOKEN);